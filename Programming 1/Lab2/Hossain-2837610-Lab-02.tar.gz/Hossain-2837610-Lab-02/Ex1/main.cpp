#include <iostream>
int main()
{
//Declaring variables and constants
double base=5.5;
double height=20.7;
double area=0.5*base*height;
std::cout<<"Triangle's base: "<<base<<std::endl;
std::cout<<"Triangle's height: "<<height<<std::endl;
std::cout<<"Area of the Triangle is: "<<area<<std::endl;
return(0);
}
