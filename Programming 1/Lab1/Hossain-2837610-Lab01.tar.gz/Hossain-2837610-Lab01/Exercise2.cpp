#include <iostream>
int main ()
{std::cout<< "My name is Shafeen Hossain.\n I am an EECS major. \n My hobbies are: \n\tSleeping\n\tVideo games \n\tLifting Weights \n\tHanging out with my friends \n Goodbye" << std:: endl;

return(0);
}
