#include "lib/doubly-linked-list/list.hpp"
#include "util/util.hpp"

DoublyLinkedList::DoublyLinkedList() {
  //IMPLEMENT ME
  IMPLEMENT_ME();
}

DoublyLinkedList::~DoublyLinkedList() {
  //IMPLEMENT ME
  IMPLEMENT_ME();
}

bool DoublyLinkedList::isEmpty() {
  //IMPLEMENT ME
  IMPLEMENT_ME();
  return true;
}

int DoublyLinkedList::size(){
  //IMPLEMENT ME
  IMPLEMENT_ME();
  return true;
}

void DoublyLinkedList::add(Edge elem, int position) {
  //IMPLEMENT ME
  IMPLEMENT_ME();
}

void DoublyLinkedList::deleteAll(Edge elem) {
  //IMPLEMENT ME
  IMPLEMENT_ME();
}

int DoublyLinkedList::find(Edge elem) {
  //IMPLEMENT ME
  IMPLEMENT_ME();
  return -1;
}

void DoublyLinkedList::print() {
  IMPLEMENT_ME();
  //IMPLEMENT ME
}
