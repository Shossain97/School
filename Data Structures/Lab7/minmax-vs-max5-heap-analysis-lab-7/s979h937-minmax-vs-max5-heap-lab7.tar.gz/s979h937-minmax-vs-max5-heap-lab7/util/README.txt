Wordlist obtained from: http://www.mit.edu/~ecprice/wordlist.10000
