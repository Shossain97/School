#include "book.hpp"
#include "util.hpp"


Book::Book(int id, std::string name, std::string publisher, int copyCount) {
  IMPLEMENT_ME();
}


int Book::getId() {
  IMPLEMENT_ME();
  return -1;
}


std::string Book::getName(){
  IMPLEMENT_ME();
  return "";
}


std::string Book::getPublisher(){
  IMPLEMENT_ME();
  return "";
}


int Book::getCurrentCount(){
  IMPLEMENT_ME();
  return -1;
}


void Book::setCurrentCount(int count){
  IMPLEMENT_ME();
}


int Book::getTotalCount(){
  IMPLEMENT_ME();
  return -1;
}


void Book::setTotalCount(int count){
  IMPLEMENT_ME();
}

