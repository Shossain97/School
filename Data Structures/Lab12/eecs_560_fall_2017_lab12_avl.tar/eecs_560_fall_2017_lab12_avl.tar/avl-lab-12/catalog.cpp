#include "catalog.hpp"
#include "util.hpp"

Catalog::Catalog(){
  IMPLEMENT_ME();
}


Catalog::~Catalog(){
  IMPLEMENT_ME();
}



void Catalog::addBook(int id, std::string bookName, std::string, int copyCount){
  IMPLEMENT_ME();
}


Book* Catalog::checkoutBook(int id){
  IMPLEMENT_ME();
  return nullptr;
}


void Catalog::returnBook(int id){
  IMPLEMENT_ME();
}

