#include "avl.hpp"
#include "util.hpp"

AVL::AVL() {
  IMPLEMENT_ME();
}

AVL::~AVL() {
  IMPLEMENT_ME();
}


bool AVL::isEmpty() {
  IMPLEMENT_ME();
  return true;
}


void AVL::addBook(Book* book) {
  IMPLEMENT_ME();
}

Book* AVL::search(int id) {
  IMPLEMENT_ME();
  return nullptr;
}


void AVL::levelorderTraverse(void (*op)(Book*)) {
  IMPLEMENT_ME();
}
